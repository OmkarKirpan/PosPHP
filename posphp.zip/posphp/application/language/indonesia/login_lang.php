<?php
$lang['login_login']='Masuk';
$lang['login_username']='Nama pengguna';
$lang['login_password']='Kata kunci';
$lang['login_go']='Lanjutkan';
$lang['login_invalid_username_and_password']='nama pengguna/kata kunci salah';
$lang['login_welcome_message']='Selamat datang di PHP Point Of Sale System. Untuk melanjutkan, silakan login menggunakan form nama pengguna dan kata kunci di bawah ini.';
?>
